Name of Project: College Life Captions

Team 223 Members: James Barquera, Zachary Strader, Joshua Patrick

Course: CST 205-02 (Multimedia Programming)

Date of Last Edit: 3/15/2017

Usage Notes: Open Main.py in a Python editor such as IDLE, 
             or run it through a command prompt terminal.
             A list will appear, prompting the user to choose
             an unedited image macro on which to place text. 
             The user can then choose between five shades of
             white or black to color their text with. Upon 
             entering captions, the user can then choose to save,
             delete, or edit the macro further, until they are 
             satisfied with the result. 
             

GitHub Repository: https://github.com/jpatrick9/Project2_Team223

Future Work: Though we were not able to do so in the span of the month we
             spent on this project, we would definitely like to integrate
             facial recognition of users through local means, and allow
             users to create image macros of themselves through an HTML
             website. This would require OpenCV and Cloud9, which are
             simple enough to integrate but also require time to integrate.  